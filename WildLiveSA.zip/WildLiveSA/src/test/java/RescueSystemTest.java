import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * JUnit 5 tests for the core functionality of the WildLife SA system.
 */
class RescueSystemTest {

    private RescueManager manager;
    private InjuredAnimalRescue injured;
    private OrphanedAnimalRescue orphaned;
    private EndangeredSpeciesRescue endangered;

    @BeforeEach
    void setUp() {
        manager = new RescueManager();
        // 5 days x R500 = R2 500 base cost in every case
        injured = new InjuredAnimalRescue("INJ001", "Leo", "Lion", "Kruger Park",
                "Sipho", 5, 500.00, "Broken leg", 3000.00, true);
        orphaned = new OrphanedAnimalRescue("ORP001", "Zola", "Rhino", "Hluhluwe",
                "Thandi", 5, 500.00, 2, 1200.00, true);
        endangered = new EndangeredSpeciesRescue("END001", "Pango", "Pangolin", "Limpopo",
                "Naledi", 5, 500.00, ConservationClassification.CRITICALLY_ENDANGERED,
                4000.00, true);
    }

    // ---------- Rescue cost calculations ----------

    @Test
    void injuredCostIncludesVetAndSurgery() {
        // 2500 + 3000 + 5000
        assertEquals(10500.00, injured.calculateTotalCost(), 0.001);
    }

    @Test
    void injuredCostWithoutSurgeryHasNoSurgeryCharge() {
        InjuredAnimalRescue noSurgery = new InjuredAnimalRescue("INJ002", "Bo", "Buck", "Umfolozi",
                "Sipho", 5, 500.00, "Cut", 3000.00, false);
        assertEquals(5500.00, noSurgery.calculateTotalCost(), 0.001);
    }

    @Test
    void orphanedCostIncludesFeedingAndFoster() {
        // 2500 + 1200 + 2500
        assertEquals(6200.00, orphaned.calculateTotalCost(), 0.001);
    }

    @Test
    void orphanedCostWithoutFosterHasNoFosterCharge() {
        OrphanedAnimalRescue noFoster = new OrphanedAnimalRescue("ORP002", "Ayo", "Zebra", "Hluhluwe",
                "Thandi", 5, 500.00, 8, 1200.00, false);
        assertEquals(3700.00, noFoster.calculateTotalCost(), 0.001);
    }

    @Test
    void endangeredCostIncludesSecurityAndSpecialistTeam() {
        // 2500 + 4000 + 8000
        assertEquals(14500.00, endangered.calculateTotalCost(), 0.001);
    }

    @Test
    void endangeredCostWithoutTeamHasNoTeamCharge() {
        EndangeredSpeciesRescue noTeam = new EndangeredSpeciesRescue("END002", "Vula", "Vulture",
                "Drakensberg", "Naledi", 5, 500.00, ConservationClassification.VULNERABLE,
                4000.00, false);
        assertEquals(6500.00, noTeam.calculateTotalCost(), 0.001);
    }

    // ---------- Rescue priority calculations ----------

    @Test
    void injuredPriorityIsCriticalWhenSurgeryRequired() {
        assertEquals(RescuePriority.CRITICAL, injured.determinePriority());
    }

    @Test
    void injuredPriorityIsHighForExpensiveTreatmentWithoutSurgery() {
        InjuredAnimalRescue expensive = new InjuredAnimalRescue("INJ003", "Bo", "Buck", "Umfolozi",
                "Sipho", 2, 500.00, "Deep wound", 6000.00, false);
        assertEquals(RescuePriority.HIGH, expensive.determinePriority());
    }

    @Test
    void injuredPriorityIsMediumForMinorInjury() {
        InjuredAnimalRescue minor = new InjuredAnimalRescue("INJ004", "Bo", "Buck", "Umfolozi",
                "Sipho", 2, 500.00, "Scratch", 800.00, false);
        assertEquals(RescuePriority.MEDIUM, minor.determinePriority());
    }

    @Test
    void orphanedPriorityDependsOnAge() {
        assertEquals(RescuePriority.CRITICAL, orphaned.determinePriority()); // 2 months
        OrphanedAnimalRescue fiveMonths = new OrphanedAnimalRescue("ORP003", "A", "Zebra", "Loc",
                "Ranger", 1, 100.00, 5, 100.00, false);
        assertEquals(RescuePriority.HIGH, fiveMonths.determinePriority());
        OrphanedAnimalRescue oneYear = new OrphanedAnimalRescue("ORP004", "B", "Zebra", "Loc",
                "Ranger", 1, 100.00, 12, 100.00, false);
        assertEquals(RescuePriority.MEDIUM, oneYear.determinePriority());
    }

    @Test
    void endangeredPriorityDependsOnClassification() {
        assertEquals(RescuePriority.CRITICAL, endangered.determinePriority());
        EndangeredSpeciesRescue e = new EndangeredSpeciesRescue("END003", "A", "Rhino", "Loc",
                "Ranger", 1, 100.00, ConservationClassification.ENDANGERED, 100.00, false);
        assertEquals(RescuePriority.HIGH, e.determinePriority());
        EndangeredSpeciesRescue v = new EndangeredSpeciesRescue("END004", "B", "Rhino", "Loc",
                "Ranger", 1, 100.00, ConservationClassification.VULNERABLE, 100.00, false);
        assertEquals(RescuePriority.MEDIUM, v.determinePriority());
    }

    // ---------- Rescue status updates ----------

    @Test
    void newCaseStartsAsReported() {
        assertEquals(RescueStatus.REPORTED, injured.getStatus());
    }

    @Test
    void startRescueMovesStatusToInProgress() {
        assertTrue(injured.startRescue());
        assertEquals(RescueStatus.IN_PROGRESS, injured.getStatus());
    }

    @Test
    void completeRescueMovesStatusToCompleted() {
        injured.startRescue();
        assertTrue(injured.completeRescue());
        assertEquals(RescueStatus.COMPLETED, injured.getStatus());
    }

    @Test
    void cannotCompleteARescueThatHasNotStarted() {
        assertFalse(injured.completeRescue());
        assertEquals(RescueStatus.REPORTED, injured.getStatus());
    }

    @Test
    void cannotStartARescueTwice() {
        injured.startRescue();
        assertFalse(injured.startRescue());
    }

    @Test
    void managerUpdatesStatusOfExistingCase() {
        manager.addRescueCase(orphaned);
        assertTrue(manager.updateStatus("ORP001", RescueStatus.COMPLETED));
        assertEquals(RescueStatus.COMPLETED, orphaned.getStatus());
    }

    @Test
    void updatingStatusOfMissingCaseFails() {
        assertFalse(manager.updateStatus("NOPE", RescueStatus.COMPLETED));
    }

    // ---------- Searching ----------

    @Test
    void searchFindsExistingCase() {
        manager.addRescueCase(injured);
        manager.addRescueCase(orphaned);
        assertSame(orphaned, manager.findById("ORP001"));
    }

    @Test
    void searchIgnoresCaseAndSpaces() {
        manager.addRescueCase(injured);
        assertSame(injured, manager.findById("  inj001 "));
    }

    @Test
    void searchReturnsNullForUnknownId() {
        manager.addRescueCase(injured);
        assertNull(manager.findById("XYZ999"));
    }

    // ---------- Duplicate IDs ----------

    @Test
    void duplicateIdIsRejected() {
        assertTrue(manager.addRescueCase(injured));
        InjuredAnimalRescue duplicate = new InjuredAnimalRescue("INJ001", "Other", "Cheetah",
                "Somewhere", "Ranger", 1, 100.00, "Injury", 100.00, false);
        assertFalse(manager.addRescueCase(duplicate));
        assertEquals(1, manager.getCount());
    }

    // ---------- Validation, summary and report ----------

    @Test
    void blankSpeciesIsRejected() {
        assertThrows(IllegalArgumentException.class, () ->
                new InjuredAnimalRescue("INJ009", "A", "  ", "Loc", "Ranger",
                        1, 100.00, "Injury", 100.00, false));
    }

    @Test
    void zeroDaysAndNegativeCostsAreRejected() {
        assertThrows(IllegalArgumentException.class, () ->
                new OrphanedAnimalRescue("ORP009", "A", "Zebra", "Loc", "Ranger",
                        0, 100.00, 4, 100.00, false));
        assertThrows(IllegalArgumentException.class, () ->
                new EndangeredSpeciesRescue("END009", "A", "Rhino", "Loc", "Ranger",
                        1, -5.00, ConservationClassification.ENDANGERED, 100.00, false));
    }

    @Test
    void summaryContainsRequiredFields() {
        String summary = injured.generateSummary();
        assertTrue(summary.contains("INJ001"));
        assertTrue(summary.contains("Injured Animal"));
        assertTrue(summary.contains("Lion"));
        assertTrue(summary.contains("Sipho"));
        assertTrue(summary.contains("Critical"));
        assertTrue(summary.contains("Reported"));
        assertTrue(summary.contains("10,500.00"));
    }

    @Test
    void totalEstimatedCostSumsAllCases() {
        manager.addRescueCase(injured);
        manager.addRescueCase(orphaned);
        manager.addRescueCase(endangered);
        // 10 500 + 6 200 + 14 500
        assertEquals(31200.00, manager.calculateTotalEstimatedCost(), 0.001);
        assertEquals(3, manager.getCount());
    }
}
