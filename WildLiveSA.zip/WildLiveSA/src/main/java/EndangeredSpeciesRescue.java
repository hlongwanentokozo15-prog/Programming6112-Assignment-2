import java.util.Locale;

/**
 * Rescue of an endangered species.
 * Total cost = (days x daily care) + security cost + R8 000 if a specialist team is required.
 */
public class EndangeredSpeciesRescue extends RescueCase {

    public static final double SPECIALIST_TEAM_COST = 8000.00;

    private ConservationClassification classification;
    private double securityCost;
    private boolean specialistTeamRequired;

    public EndangeredSpeciesRescue(String caseId, String animalName, String species,
                                   String rescueLocation, String assignedRanger,
                                   int rescueDays, double dailyCareCost,
                                   ConservationClassification classification,
                                   double securityCost, boolean specialistTeamRequired) {
        super(caseId, animalName, species, rescueLocation, assignedRanger, rescueDays, dailyCareCost);
        if (classification == null) {
            throw new IllegalArgumentException("Conservation classification cannot be null.");
        }
        if (securityCost <= 0) {
            throw new IllegalArgumentException("Security cost must be greater than zero.");
        }
        this.classification = classification;
        this.securityCost = securityCost;
        this.specialistTeamRequired = specialistTeamRequired;
    }

    @Override
    public String getRescueType() {
        return "Endangered Species";
    }

    @Override
    public double calculateTotalCost() {
        double total = calculateBaseCost() + securityCost;
        if (specialistTeamRequired) {
            total += SPECIALIST_TEAM_COST;
        }
        return total;
    }

    /** Critically Endangered = Critical; Endangered = High; Vulnerable = Medium. */
    @Override
    public RescuePriority determinePriority() {
        switch (classification) {
            case CRITICALLY_ENDANGERED:
                return RescuePriority.CRITICAL;
            case ENDANGERED:
                return RescuePriority.HIGH;
            default:
                return RescuePriority.MEDIUM;
        }
    }

    @Override
    public String displaySpecificDetails() {
        return String.format(Locale.US,
                "Classification : %s%n"
              + "Security Cost  : R%,.2f%n"
              + "Specialist Team: %s%n",
                classification, securityCost, specialistTeamRequired ? "Yes" : "No");
    }

    public ConservationClassification getClassification() { return classification; }
    public double getSecurityCost() { return securityCost; }
    public boolean isSpecialistTeamRequired() { return specialistTeamRequired; }
}
