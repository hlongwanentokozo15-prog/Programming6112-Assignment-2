import java.util.Locale;

/**
 * Rescue of an orphaned animal.
 * Total cost = (days x daily care) + feeding cost + R2 500 if foster care is required.
 */
public class OrphanedAnimalRescue extends RescueCase {

    public static final double FOSTER_CARE_COST = 2500.00;

    private int estimatedAgeMonths;
    private double feedingCost;
    private boolean fosterCareRequired;

    public OrphanedAnimalRescue(String caseId, String animalName, String species,
                                String rescueLocation, String assignedRanger,
                                int rescueDays, double dailyCareCost,
                                int estimatedAgeMonths, double feedingCost,
                                boolean fosterCareRequired) {
        super(caseId, animalName, species, rescueLocation, assignedRanger, rescueDays, dailyCareCost);
        if (estimatedAgeMonths <= 0) {
            throw new IllegalArgumentException("Estimated age must be greater than zero.");
        }
        if (feedingCost <= 0) {
            throw new IllegalArgumentException("Feeding cost must be greater than zero.");
        }
        this.estimatedAgeMonths = estimatedAgeMonths;
        this.feedingCost = feedingCost;
        this.fosterCareRequired = fosterCareRequired;
    }

    @Override
    public String getRescueType() {
        return "Orphaned Animal";
    }

    @Override
    public double calculateTotalCost() {
        double total = calculateBaseCost() + feedingCost;
        if (fosterCareRequired) {
            total += FOSTER_CARE_COST;
        }
        return total;
    }

    /** Very young (3 months or less) = Critical; under 6 months = High; otherwise Medium. */
    @Override
    public RescuePriority determinePriority() {
        if (estimatedAgeMonths <= 3) {
            return RescuePriority.CRITICAL;
        }
        if (estimatedAgeMonths < 6) {
            return RescuePriority.HIGH;
        }
        return RescuePriority.MEDIUM;
    }

    @Override
    public String displaySpecificDetails() {
        return String.format(Locale.US,
                "Est. Age       : %d months%n"
              + "Feeding Cost   : R%,.2f%n"
              + "Foster Care    : %s%n",
                estimatedAgeMonths, feedingCost, fosterCareRequired ? "Yes" : "No");
    }

    public int getEstimatedAgeMonths() { return estimatedAgeMonths; }
    public double getFeedingCost() { return feedingCost; }
    public boolean isFosterCareRequired() { return fosterCareRequired; }
}
