import java.util.Locale;

/**
 * Abstract base class holding the information shared by all rescue cases.
 * Subclasses supply their own cost, priority, type name and extra details
 * (abstraction + polymorphism).
 */
public abstract class RescueCase implements RescueOperations {

    // Encapsulation: all fields are private
    private final String caseId;
    private String animalName;
    private String species;
    private String rescueLocation;
    private String assignedRanger;
    private int rescueDays;
    private double dailyCareCost;
    private RescueStatus status;

    protected RescueCase(String caseId, String animalName, String species,
                         String rescueLocation, String assignedRanger,
                         int rescueDays, double dailyCareCost) {
        requireText(caseId, "Rescue Case ID");
        requireText(species, "Species");
        requireText(rescueLocation, "Rescue Location");
        requireText(assignedRanger, "Assigned Ranger");
        if (rescueDays <= 0) {
            throw new IllegalArgumentException("Number of rescue days must be greater than zero.");
        }
        if (dailyCareCost <= 0) {
            throw new IllegalArgumentException("Daily care cost must be greater than zero.");
        }
        this.caseId = caseId.trim();
        this.animalName = (animalName == null || animalName.isBlank()) ? "Unnamed" : animalName.trim();
        this.species = species.trim();
        this.rescueLocation = rescueLocation.trim();
        this.assignedRanger = assignedRanger.trim();
        this.rescueDays = rescueDays;
        this.dailyCareCost = dailyCareCost;
        this.status = RescueStatus.REPORTED; // every new case starts as Reported
    }

    /** Shared validation helper for required text fields. */
    protected static void requireText(String value, String fieldName) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(fieldName + " cannot be blank.");
        }
    }

    // ---------- Abstract methods: each rescue type implements its own ----------

    /** @return the type name, e.g. "Injured Animal Rescue" */
    public abstract String getRescueType();

    /** @return the total rescue cost including type-specific costs */
    public abstract double calculateTotalCost();

    /** @return the priority based on the rescue type's own rules */
    public abstract RescuePriority determinePriority();

    /** @return the extra information specific to this rescue type */
    public abstract String displaySpecificDetails();

    // ---------- Shared behaviour ----------

    /** Cost of daily care over the whole rescue (shared by all types). */
    protected double calculateBaseCost() {
        return rescueDays * dailyCareCost;
    }

    @Override
    public boolean startRescue() {
        if (status == RescueStatus.REPORTED) {
            status = RescueStatus.IN_PROGRESS;
            return true;
        }
        return false;
    }

    @Override
    public boolean completeRescue() {
        if (status == RescueStatus.IN_PROGRESS) {
            status = RescueStatus.COMPLETED;
            return true;
        }
        return false;
    }

    @Override
    public String generateSummary() {
        return String.format(Locale.US,
                "----- Rescue Summary -----%n"
              + "Rescue Case ID : %s%n"
              + "Rescue Type    : %s%n"
              + "Species        : %s%n"
              + "Assigned Ranger: %s%n"
              + "Rescue Priority: %s%n"
              + "Current Status : %s%n"
              + "Total Cost     : R%,.2f%n",
                caseId, getRescueType(), species, assignedRanger,
                determinePriority(), status, calculateTotalCost());
    }

    /** Full details of the case, including the type-specific information. */
    public String displayFullDetails() {
        return String.format(Locale.US,
                "Rescue Case ID : %s%n"
              + "Rescue Type    : %s%n"
              + "Animal Name    : %s%n"
              + "Species        : %s%n"
              + "Location       : %s%n"
              + "Assigned Ranger: %s%n"
              + "Rescue Days    : %d%n"
              + "Daily Care Cost: R%,.2f%n"
              + "Status         : %s%n"
              + "%s"
              + "Priority       : %s%n"
              + "Total Cost     : R%,.2f%n",
                caseId, getRescueType(), animalName, species, rescueLocation,
                assignedRanger, rescueDays, dailyCareCost, status,
                displaySpecificDetails(), determinePriority(), calculateTotalCost());
    }

    // ---------- Getters / setters ----------

    public String getCaseId() { return caseId; }
    public String getAnimalName() { return animalName; }
    public String getSpecies() { return species; }
    public String getRescueLocation() { return rescueLocation; }
    public String getAssignedRanger() { return assignedRanger; }
    public int getRescueDays() { return rescueDays; }
    public double getDailyCareCost() { return dailyCareCost; }
    public RescueStatus getStatus() { return status; }

    public void setStatus(RescueStatus status) {
        if (status == null) {
            throw new IllegalArgumentException("Status cannot be null.");
        }
        this.status = status;
    }
}
