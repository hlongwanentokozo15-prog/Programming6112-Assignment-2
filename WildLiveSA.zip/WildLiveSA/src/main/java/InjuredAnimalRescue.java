import java.util.Locale;

/**
 * Rescue of an injured animal.
 * Total cost = (days x daily care) + veterinary cost + R5 000 if surgery is required.
 */
public class InjuredAnimalRescue extends RescueCase {

    public static final double SURGERY_COST = 5000.00;
    /** Vet bills at or above this amount raise the priority to High. */
    public static final double HIGH_VET_COST_THRESHOLD = 5000.00;

    private String injuryDescription;
    private double veterinaryCost;
    private boolean surgeryRequired;

    public InjuredAnimalRescue(String caseId, String animalName, String species,
                               String rescueLocation, String assignedRanger,
                               int rescueDays, double dailyCareCost,
                               String injuryDescription, double veterinaryCost,
                               boolean surgeryRequired) {
        super(caseId, animalName, species, rescueLocation, assignedRanger, rescueDays, dailyCareCost);
        requireText(injuryDescription, "Injury description");
        if (veterinaryCost <= 0) {
            throw new IllegalArgumentException("Veterinary treatment cost must be greater than zero.");
        }
        this.injuryDescription = injuryDescription.trim();
        this.veterinaryCost = veterinaryCost;
        this.surgeryRequired = surgeryRequired;
    }

    @Override
    public String getRescueType() {
        return "Injured Animal";
    }

    @Override
    public double calculateTotalCost() {
        double total = calculateBaseCost() + veterinaryCost;
        if (surgeryRequired) {
            total += SURGERY_COST;
        }
        return total;
    }

    /** Surgery = Critical; expensive treatment = High; otherwise Medium. */
    @Override
    public RescuePriority determinePriority() {
        if (surgeryRequired) {
            return RescuePriority.CRITICAL;
        }
        if (veterinaryCost >= HIGH_VET_COST_THRESHOLD) {
            return RescuePriority.HIGH;
        }
        return RescuePriority.MEDIUM;
    }

    @Override
    public String displaySpecificDetails() {
        return String.format(Locale.US,
                "Injury         : %s%n"
              + "Vet Cost       : R%,.2f%n"
              + "Surgery Needed : %s%n",
                injuryDescription, veterinaryCost, surgeryRequired ? "Yes" : "No");
    }

    public String getInjuryDescription() { return injuryDescription; }
    public double getVeterinaryCost() { return veterinaryCost; }
    public boolean isSurgeryRequired() { return surgeryRequired; }
}
