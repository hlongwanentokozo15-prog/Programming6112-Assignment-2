/**
 * Interface: every rescue case type must support these operations.
 */
public interface RescueOperations {

    /**
     * Starts the rescue. Only allowed while the case is REPORTED.
     * @return true if the rescue was started, false if the status did not allow it
     */
    boolean startRescue();

    /**
     * Completes the rescue. Only allowed while the case is IN_PROGRESS.
     * @return true if the rescue was completed, false if the status did not allow it
     */
    boolean completeRescue();

    /**
     * @return a formatted summary of the rescue case
     */
    String generateSummary();
}
