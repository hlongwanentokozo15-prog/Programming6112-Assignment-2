/**
 * Conservation status of an endangered species (IUCN-style categories).
 */
public enum ConservationClassification {
    VULNERABLE("Vulnerable"),
    ENDANGERED("Endangered"),
    CRITICALLY_ENDANGERED("Critically Endangered");

    private final String label;

    ConservationClassification(String label) {
        this.label = label;
    }

    @Override
    public String toString() {
        return label;
    }
}
