import java.util.Scanner;

/**
 * Reads and validates console input. Every method keeps asking until the
 * input is valid, so the program never crashes on bad input.
 */
public class InputHelper {

    private final Scanner scanner;

    public InputHelper(Scanner scanner) {
        this.scanner = scanner;
    }

    /** Reads a non-blank line of text. */
    public String readNonBlank(String prompt, String fieldName) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            if (!input.isEmpty()) {
                return input;
            }
            System.out.println("Error: " + fieldName + " cannot be blank. Please try again.");
        }
    }

    /** Reads optional text (blank allowed). */
    public String readOptional(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    /** Reads a whole number greater than zero. */
    public int readPositiveInt(String prompt, String fieldName) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                int value = Integer.parseInt(input);
                if (value > 0) {
                    return value;
                }
                System.out.println("Error: " + fieldName + " must be greater than zero.");
            } catch (NumberFormatException e) {
                System.out.println("Error: please enter a valid whole number.");
            }
        }
    }

    /** Reads a decimal number greater than zero. */
    public double readPositiveDouble(String prompt, String fieldName) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                double value = Double.parseDouble(input);
                if (Double.isNaN(value) || Double.isInfinite(value)) {
                    System.out.println("Error: please enter a valid number.");
                } else if (value > 0) {
                    return value;
                } else {
                    System.out.println("Error: " + fieldName + " must be greater than zero.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: please enter a valid number (e.g. 1500.50).");
            }
        }
    }

    /** Reads Y/N and returns true for yes. */
    public boolean readYesNo(String prompt) {
        while (true) {
            System.out.print(prompt + " (Y/N): ");
            String input = scanner.nextLine().trim();
            if (input.equalsIgnoreCase("Y") || input.equalsIgnoreCase("YES")) {
                return true;
            }
            if (input.equalsIgnoreCase("N") || input.equalsIgnoreCase("NO")) {
                return false;
            }
            System.out.println("Error: please enter Y or N.");
        }
    }

    /** Reads a menu choice between min and max (inclusive). */
    public int readMenuChoice(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                int choice = Integer.parseInt(input);
                if (choice >= min && choice <= max) {
                    return choice;
                }
            } catch (NumberFormatException e) {
                // fall through to the error message below
            }
            System.out.println("Error: invalid selection. Please enter a number from " + min + " to " + max + ".");
        }
    }
}
