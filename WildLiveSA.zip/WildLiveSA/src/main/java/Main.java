import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 * WildLife SA - Wildlife Rescue Operations System (console application).
 */
public class Main {

    private static final RescueManager manager = new RescueManager();
    private static InputHelper input;

    public static void main(String[] args) {
        input = new InputHelper(new Scanner(System.in));
        System.out.println("=== WildLife SA Rescue Operations System ===");

        boolean running = true;
        try {
            while (running) {
                printMenu();
                int choice = input.readMenuChoice("Enter your choice: ", 1, 9);
                System.out.println();
                switch (choice) {
                    case 1: createRescueCase(); break;
                    case 2: searchRescueCase(); break;
                    case 3: updateStatus(); break;
                    case 4: displayAll(); break;
                    case 5: startRescue(); break;
                    case 6: completeRescue(); break;
                    case 7: showSummary(); break;
                    case 8: System.out.println(manager.generateReport()); break;
                    case 9:
                        System.out.println("Thank you for helping protect Southern Africa's wildlife. Goodbye!");
                        running = false;
                        break;
                    default: break;
                }
            }
        } catch (NoSuchElementException e) {
            // Input stream closed (e.g. Ctrl+D) - exit cleanly
            System.out.println("\nInput closed. Exiting.");
        }
    }

    private static void printMenu() {
        System.out.println();
        System.out.println("---------------- MAIN MENU ----------------");
        System.out.println("1. Create a new rescue case");
        System.out.println("2. Search for a rescue case");
        System.out.println("3. Update rescue status");
        System.out.println("4. Display all rescue cases");
        System.out.println("5. Start a rescue operation");
        System.out.println("6. Complete a rescue operation");
        System.out.println("7. Generate rescue summary");
        System.out.println("8. Generate rescue report");
        System.out.println("9. Exit");
        System.out.println("-------------------------------------------");
    }

    // ---------- 1. Create ----------

    private static void createRescueCase() {
        System.out.println("Select rescue type:");
        System.out.println("1. Injured Animal Rescue");
        System.out.println("2. Orphaned Animal Rescue");
        System.out.println("3. Endangered Species Rescue");
        int type = input.readMenuChoice("Enter type: ", 1, 3);

        // Common details
        String id = readUniqueId();
        String animalName = input.readOptional("Animal name (optional): ");
        String species = input.readNonBlank("Species: ", "Species");
        String location = input.readNonBlank("Rescue location: ", "Rescue location");
        String ranger = input.readNonBlank("Assigned ranger: ", "Assigned ranger");
        int days = input.readPositiveInt("Number of rescue days: ", "Number of rescue days");
        double dailyCost = input.readPositiveDouble("Daily care cost (R): ", "Daily care cost");

        RescueCase rescueCase;
        switch (type) {
            case 1: {
                String injury = input.readNonBlank("Injury description: ", "Injury description");
                double vet = input.readPositiveDouble("Veterinary treatment cost (R): ", "Veterinary cost");
                boolean surgery = input.readYesNo("Is surgery required? (extra R5 000)");
                rescueCase = new InjuredAnimalRescue(id, animalName, species, location, ranger,
                        days, dailyCost, injury, vet, surgery);
                break;
            }
            case 2: {
                int age = input.readPositiveInt("Estimated age (months): ", "Estimated age");
                double feeding = input.readPositiveDouble("Feeding cost (R): ", "Feeding cost");
                boolean foster = input.readYesNo("Is foster care required? (extra R2 500)");
                rescueCase = new OrphanedAnimalRescue(id, animalName, species, location, ranger,
                        days, dailyCost, age, feeding, foster);
                break;
            }
            default: {
                System.out.println("Conservation classification:");
                System.out.println("1. Vulnerable");
                System.out.println("2. Endangered");
                System.out.println("3. Critically Endangered");
                int c = input.readMenuChoice("Enter classification: ", 1, 3);
                ConservationClassification classification = ConservationClassification.values()[c - 1];
                double security = input.readPositiveDouble("Security cost (R): ", "Security cost");
                boolean team = input.readYesNo("Is a specialist team required? (extra R8 000)");
                rescueCase = new EndangeredSpeciesRescue(id, animalName, species, location, ranger,
                        days, dailyCost, classification, security, team);
                break;
            }
        }

        if (manager.addRescueCase(rescueCase)) {
            System.out.println("\nRescue case " + rescueCase.getCaseId() + " created successfully.");
        } else {
            System.out.println("\nError: the rescue case could not be added.");
        }
    }

    /** Keeps asking until the ID is not blank and not already in use. */
    private static String readUniqueId() {
        while (true) {
            String id = input.readNonBlank("Rescue case ID: ", "Rescue case ID");
            if (manager.idExists(id)) {
                System.out.println("Error: Rescue Case ID '" + id + "' already exists. IDs must be unique.");
            } else {
                return id;
            }
        }
    }

    // ---------- 2. Search ----------

    private static void searchRescueCase() {
        String id = input.readNonBlank("Enter Rescue Case ID to search: ", "Rescue case ID");
        RescueCase rc = manager.findById(id);
        if (rc == null) {
            System.out.println("No rescue case found with ID '" + id + "'.");
        } else {
            System.out.println("\n----- Rescue Case Found -----");
            System.out.println(rc.displayFullDetails());
        }
    }

    // ---------- 3. Update status ----------

    private static void updateStatus() {
        if (manager.isEmpty()) {
            System.out.println("There are no rescue cases to update.");
            return;
        }
        String id = input.readNonBlank("Enter Rescue Case ID to update: ", "Rescue case ID");
        RescueCase rc = manager.findById(id);
        if (rc == null) {
            System.out.println("No rescue case found with ID '" + id + "'.");
            return;
        }
        System.out.println("Current status: " + rc.getStatus());
        System.out.println("Select new status:");
        RescueStatus[] statuses = RescueStatus.values();
        for (int i = 0; i < statuses.length; i++) {
            System.out.println((i + 1) + ". " + statuses[i]);
        }
        int choice = input.readMenuChoice("Enter status: ", 1, statuses.length);
        manager.updateStatus(rc.getCaseId(), statuses[choice - 1]);
        System.out.println("Status updated to: " + rc.getStatus());
    }

    // ---------- 4. Display all ----------

    private static void displayAll() {
        if (manager.isEmpty()) {
            System.out.println("No rescue cases have been recorded yet.");
            return;
        }
        int number = 1;
        for (RescueCase rc : manager.getAllCases()) {
            System.out.println("----- Rescue Case " + number++ + " -----");
            System.out.println(rc.displayFullDetails()); // polymorphic call
        }
    }

    // ---------- 5-7. Rescue operations ----------

    private static RescueCase askForCase() {
        if (manager.isEmpty()) {
            System.out.println("There are no rescue cases yet.");
            return null;
        }
        String id = input.readNonBlank("Enter Rescue Case ID: ", "Rescue case ID");
        RescueCase rc = manager.findById(id);
        if (rc == null) {
            System.out.println("No rescue case found with ID '" + id + "'.");
        }
        return rc;
    }

    private static void startRescue() {
        RescueCase rc = askForCase();
        if (rc == null) return;
        if (rc.startRescue()) {
            System.out.println("Rescue started. Status is now: " + rc.getStatus());
        } else {
            System.out.println("Cannot start rescue. Current status is '" + rc.getStatus()
                    + "' (only Reported cases can be started).");
        }
    }

    private static void completeRescue() {
        RescueCase rc = askForCase();
        if (rc == null) return;
        if (rc.completeRescue()) {
            System.out.println("Rescue completed. Status is now: " + rc.getStatus());
        } else {
            System.out.println("Cannot complete rescue. Current status is '" + rc.getStatus()
                    + "' (only In Progress cases can be completed).");
        }
    }

    private static void showSummary() {
        RescueCase rc = askForCase();
        if (rc == null) return;
        System.out.println(rc.generateSummary());
    }
}
