import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Manages all rescue cases. Cases are stored in an ArrayList (in memory only).
 */
public class RescueManager {

    private final ArrayList<RescueCase> rescueCases = new ArrayList<>();

    /** @return true if a case with this ID (ignoring case/spaces) already exists */
    public boolean idExists(String caseId) {
        return findById(caseId) != null;
    }

    /**
     * Adds a rescue case.
     * @return true if added, false if the ID is a duplicate or the case is null
     */
    public boolean addRescueCase(RescueCase rescueCase) {
        if (rescueCase == null || idExists(rescueCase.getCaseId())) {
            return false;
        }
        rescueCases.add(rescueCase);
        return true;
    }

    /** @return the matching case, or null if none exists */
    public RescueCase findById(String caseId) {
        if (caseId == null) {
            return null;
        }
        String wanted = caseId.trim();
        for (RescueCase rc : rescueCases) {
            if (rc.getCaseId().equalsIgnoreCase(wanted)) {
                return rc;
            }
        }
        return null;
    }

    /** Updates the status of an existing case. @return false if the case was not found */
    public boolean updateStatus(String caseId, RescueStatus newStatus) {
        RescueCase rc = findById(caseId);
        if (rc == null || newStatus == null) {
            return false;
        }
        rc.setStatus(newStatus);
        return true;
    }

    public int getCount() {
        return rescueCases.size();
    }

    public boolean isEmpty() {
        return rescueCases.isEmpty();
    }

    /** @return a copy, so callers cannot change the internal list */
    public List<RescueCase> getAllCases() {
        return new ArrayList<>(rescueCases);
    }

    public double calculateTotalEstimatedCost() {
        double total = 0;
        for (RescueCase rc : rescueCases) {
            total += rc.calculateTotalCost(); // polymorphic call
        }
        return total;
    }

    /** Builds the full rescue report. */
    public String generateReport() {
        StringBuilder sb = new StringBuilder();
        String line = "=".repeat(128);
        sb.append(line).append(System.lineSeparator());
        sb.append("                                   WILDLIFE SA - RESCUE REPORT").append(System.lineSeparator());
        sb.append(line).append(System.lineSeparator());
        sb.append(String.format("%-10s %-20s %-16s %-20s %-16s %-10s %-12s %14s%n",
                "Case ID", "Rescue Type", "Species", "Location", "Ranger",
                "Priority", "Status", "Total Cost"));
        sb.append("-".repeat(128)).append(System.lineSeparator());

        if (rescueCases.isEmpty()) {
            sb.append("No rescue cases recorded.").append(System.lineSeparator());
        }
        for (RescueCase rc : rescueCases) {
            sb.append(String.format(Locale.US, "%-10s %-20s %-16s %-20s %-16s %-10s %-12s %14s%n",
                    cut(rc.getCaseId(), 10), cut(rc.getRescueType(), 20),
                    cut(rc.getSpecies(), 16), cut(rc.getRescueLocation(), 20),
                    cut(rc.getAssignedRanger(), 16), rc.determinePriority(),
                    rc.getStatus(), String.format(Locale.US, "R%,.2f", rc.calculateTotalCost())));
        }

        sb.append(line).append(System.lineSeparator());
        sb.append(String.format(Locale.US, "Total number of rescue cases : %d%n", getCount()));
        sb.append(String.format(Locale.US, "Total estimated rescue cost  : R%,.2f%n", calculateTotalEstimatedCost()));
        sb.append(line).append(System.lineSeparator());
        return sb.toString();
    }

    /** Shortens text so the report columns stay aligned. */
    private static String cut(String text, int max) {
        return text.length() <= max ? text : text.substring(0, max - 1) + ".";
    }
}
